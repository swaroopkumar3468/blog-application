const config = {
  BASE_URL: "http://localhost:5001",
};
export default config;
